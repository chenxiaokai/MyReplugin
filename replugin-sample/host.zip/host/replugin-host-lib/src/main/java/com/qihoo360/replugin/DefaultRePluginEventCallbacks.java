package com.qihoo360.replugin;

import android.content.Context;

/**
 * @deprecated Use RePluginEventCallbacks instead
 * @see RePluginEventCallbacks
 * @author RePlugin Team
 */

public class DefaultRePluginEventCallbacks extends RePluginEventCallbacks {

    /**
     * @deprecated Use RePluginEventCallbacks instead
     * @see RePluginEventCallbacks#RePluginEventCallbacks(Context)
     */
    public DefaultRePluginEventCallbacks(Context context) {
        super(context);
    }
}
